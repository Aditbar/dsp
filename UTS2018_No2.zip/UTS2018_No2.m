close all
clear all

[delta,n]=impseq(0,0,50);
%Cara Analitik
b=1;
a=poly([0.8,0.8]);
ya=filter(b,a,delta);

%(0.8)^n *u(n)
[u,n1]=stepseq(0,0,50);
x=(0.8).^n.*u;

%Cara conv
y=conv(x,x);
m=n1;
%Ubah ke 50 sampel pertama dari hasil konvolusi
y50=y(1,1:51);


%plot
subplot(211);
plot(n,ya);
grid on
title('Cara Analitik');
xlabel('n');
ylabel('Magnitude');

subplot(212);
plot(m,y50);
title('Cara Convolusi MATLAB');
xlabel('n');
ylabel('Magnitude');
grid on