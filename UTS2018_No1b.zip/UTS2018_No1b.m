clear all
close all
%x(n)+2x(n-1)-x(n-2)

n=0:100;
x1=rand(1,length(n));
x2=sqrt(10)*randn(1,length(n));
%x1
[x11,n11]=sigshift(x1,n,1);     %2x(n-1)
x11=2*x11;
[x21,n21]=sigshift(x1,n,2);     %-x(n-2)
x21=-1*x21;
[y1,m1]=sigadd(x1,n,x11,n11);
[y1,m1]=sigadd(y1,m1,x21,n21);

%x2
[x12,n12]=sigshift(x2,n,1);     %2x(n-1)
x12=2*x12;
[x22,n22]=sigshift(x2,n,2);     %-x(n-2)
x22=-1*x22;
[y2,m2]=sigadd(x2,n,x12,n12);
[y2,m2]=sigadd(y2,m2,x22,n22);

%y
xs=x1+x2;
[xs1,ns1]=sigshift(xs,n,1);     %2x(n-1)
xs1=2*xs1;
[xs2,ns2]=sigshift(xs,n,2);     %-x(n-2)
xs2=-1*xs2;
[y,m]=sigadd(xs,n,xs1,ns1);
[y,m]=sigadd(y,m,xs2,ns2);

%Linearity
diff=sum(abs(y-(y1+y2)));
if (diff < 1e-5)
    disp(' Sistem Linear');
else
    disp('Sistem Tidak Linear');
end