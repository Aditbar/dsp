close all
clear all

%2^x(n)
n=0:100;
x1=rand(1,length(n));
x2=sqrt(10)*randn(1,length(n));

%x1
x11=2.^(x1);

%x2
x22=2.^(x2);

%y
xs=x1+x2;
y=2.^(xs);

%Linearitas
diff=sum(abs(y-(x11+x22)));
if (diff < 1e-5)
    disp(' Sistem Linear');
else
    disp('Sistem Tidak Linear');
end